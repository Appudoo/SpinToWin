using System.Collections;
using System.Collections.Generic;
using System.Data;
using UnityEngine;

public class DataManager : MonoBehaviour
{
    public static string baseurl = "https://technofysolution.com/spinwinnew/API_V1.php";

    public static string id;
    public static string mail;
    public static string device_token;
    public static int tot_spin;
    public static string tot_withdraw;

    public static string upiId1;
    public static string upiId2;

    public static string Upi;
    public static int Amount;
    public static int Spinadd;

    public static int islive;
}
